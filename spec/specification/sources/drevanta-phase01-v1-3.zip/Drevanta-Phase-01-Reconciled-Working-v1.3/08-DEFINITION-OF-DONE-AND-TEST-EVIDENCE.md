# Definition of Done and Verification Evidence — Initial Standard

**Status:** Proposed engineering governance; to be reconciled and approved.

## Feature done
1. Requirement and scope approved; linked to source and feature ID.
2. Implementation meets UI, API, persistence, orchestration, permission, and VPS contracts where applicable.
3. Positive, negative, boundary, error, timeout, and recovery paths tested.
4. Unauthorized, cross-tenant, and privilege-escalation attempts rejected by server-side checks.
5. Logs/audit/metrics exist as specified, without secret leakage.
6. Tests and evidence linked to exact commit, environment, and version.
7. Documentation and migration/rollback instructions updated.

## Module done
All required feature gates passed; API/schema compatibility checked; integration, security, failure injection, and regression tests passed; unresolved release blockers = 0.

## Phase done
Required deliverables reviewed; dependencies and decision records resolved or explicitly deferred; test matrix and operational runbooks completed; acceptance evidence attached.

## Release done
Reproducible build, signed/tagged artifact policy (decision pending), CI green, dependency and vulnerability review, least-privilege checks, isolated staging VPS end-to-end verification, backup/restore and upgrade/rollback exercises, release notes, incident/runbook readiness, approved change window and human authorization for production deployment. No unverified claim of 'production ready'.

## Test matrix (minimum categories; applicability per feature)
| Category | Representative requirement | Evidence |
|---|---|---|
| Unit | Validation and state transitions | CI test report |
| API contract | Schema, status codes, idempotency, pagination | Contract test output |
| Integration | DB/queue/agent/webserver interactions | Isolated environment report |
| End-to-end | Browser-to-VPS success and failure flows | Scenario results and screenshots |
| Auth and tenancy | Cross-role and cross-tenant denial | Permission matrix results |
| Security | Threat cases, secret handling, injection, CSRF, SSRF | Security findings and remediation |
| VPS | Allowlisted commands, OS compatibility, permissions | Disposable VPS logs |
| Reliability | Retry, cancellation, partial failure, reconciliation | Fault injection evidence |
| Data | Migration, backup, restore, retention, deletion | Integrity checks |
| Upgrade/release | Clean install, upgrade, rollback | Release verification record |
| Performance | Capacity, latency, resource limits | Benchmark report against approved SLOs |
| Accessibility | Keyboard, focus, labels, contrast | Accessibility audit |

## Agent stop conditions
Stop and request human decision when requirements conflict; privileges are unclear; a secret is exposed; tests fail in ways not covered by an approved recovery procedure; data loss is possible; production changes are required; or a security boundary cannot be verified. Never mark a test passed without captured evidence.
