# Drevanta — Phase 01: Master Platform Inventory and Scope Registry

**Version:** 1.0 · **Status:** Initial evidence-based baseline / not yet approved as exhaustive · **Date:** 2026-11-13

## Executive assessment

The 24-phase master plan is designed to cover Drevanta to the engineering core: UI, permissions, services, data, APIs, background jobs, Linux/VPS operations, security, monitoring, backup/recovery, release, and tests. **This first inventory is not an assertion of completeness.** It establishes source-backed evidence, traceability candidates, scope categories, decisions and gaps to resolve before writing binding contracts.

## Sources examined

The approved integrated prototype directory `Drevanta-Final-Approved-v2.1/` was used as the baseline. Documents: Phase-2-Source-Specification.md, Persona-2-Source-PRD.md, Persona-3-Source-PRD.md, Persona-4-Source-PRD.md, FEATURE-MAP.md, PERSONA2-FEATURE-MAP.md, FOUR-PERSONA-FEATURE-MAP.md, AUTHENTICATION-DESIGN-NOTES.md, INTEGRATION-NOTES.md, FINAL-RELEASE-NOTES.md. The package includes HTML, CSS and JS for four personas, onboarding, and authentication.

## Evidence counts

- **478** document headings captured with exact source file and line number as **classification candidates**, not approved feature counts.
- **31** HTML entry pages inventoried; dynamic routes and UI controls require additional analysis.
- **55** potential JS labels extracted as review candidates; some may be metadata rather than UI controls.
- **27** platform inventory categories; none are automatically committed scope.
- **15** initial unresolved architecture decisions.
- **12** initial explicit gaps and risks.

## Existing established decisions

1. Four separate personas: Server & Platform Administration; Hosting Provider/Reseller/Agency; Website Owner; Developer.
2. Original teal/slate design is the default; alternative accessible palettes and light/dark controls remain.
3. Onboarding includes initial administrator, MFA, recovery codes, server-IP access and optional custom domain; frontend verification is simulated.
4. Authentication includes login, MFA challenge, email recovery and authorized server-owner recovery design; **no live authentication is implemented**.
5. Existing workspace switching is presentation-only and must not be treated as RBAC.
6. The approved integrated UI is the visual reference, not an authoritative implementation of backend security or host operations.

## Inventory methodology

**Pass A (included in this package):** inspect source documents and file structure; capture heading-level candidates with provenance, HTML entry points, JS label candidates; establish domain categories, roadmap, gaps and decision register.

**Pass B (required before claiming exhaustive inventory):** classify each heading as feature, policy, constraint, architecture, exclusion or duplicate; reconcile actual PRD section bodies against approved UI decisions; inspect JS-rendered navigation, modals, actions, settings and conditional states; run browser journeys for all four personas, onboarding and authentication.

**Pass C:** assign canonical capability IDs and explicit approval status; map every UI control to permission, API, data entity, job, VPS operation, security control and acceptance tests; distinguish N/A from TBD; review contradictions and obtain scope decisions.

## Registry conventions

Canonical feature record fields: `feature_id, name, domain_id, persona, workspace, source_reference, source_line, UI_route, UI_control, requirement_status, spec_status, implementation_status, verification_status, release_status, owner_scope, permission, API_route, data_entities, job_type, VPS_dependency, audit_event, phase, dependencies, acceptance_tests, open_decisions`.

**Statuses are independent.** An approved requirement can remain unimplemented. A visible prototype control is not evidence of a functioning backend.

## Cross-cutting design invariants to specify

- Server-side authorization on every read and mutation; tenant and resource ownership boundaries enforced at API and job execution.
- Privileged Linux operations run through a constrained, auditable execution boundary; no arbitrary shell from user input.
- Durable asynchronous operations with idempotency, retries, timeout, cancellation rules, status reporting and reconciliation.
- Secure identity lifecycle: one-time setup trust, MFA and recovery, session rotation/revocation, rate limiting and non-enumerating errors.
- Configuration drift detection, rollback where feasible, failure diagnostics, and documented manual recovery for non-reversible actions.
- Secrets handling, audit integrity, observability, tested restore procedures, upgrade and migration safety.

## Canonical feature specification template

1. Purpose, business justification and scope.
2. Source provenance, approval status and exclusions.
3. Actors, permissions, ownership, tenant isolation and threat boundaries.
4. User journeys, UI controls, validation and all states.
5. API route, request/response schemas, auth, errors and idempotency.
6. Data model, constraints, state machine, migrations and retention.
7. Job orchestration, timeouts, retries, cancellation and progress.
8. VPS operations, exact service ownership, filesystem and privilege model.
9. Security, audit events, abuse protection and secret handling.
10. Monitoring, backup, recovery, rollback and support diagnostics.
11. Decisions, alternatives, dependencies and open questions.
12. Implementation tasks, tests, acceptance criteria and definition of done.

## Phase map

See `05-documentation-roadmap.csv` for all 24 initial phases. Their numbers are documentation sequence identifiers, not implementation sprints. The phase map can expand based on findings.

## Critical caveats

- **Not production-ready:** the source package is a browser prototype; no real host agent, provisioning, RBAC, MFA verification, reset email, persistent jobs or audit pipeline is evidenced.
- **Not a final capability list:** heading extraction is an indexing technique, not semantic classification.
- **Not a complete UI control audit:** JS-generated controls require a second pass.
- **No silent approvals:** PHP/Node/Python, mailboxes, billing, cloud provider integrations, specific DBs and server agents must be reconciled with requirements.

## Immediate next review gates

1. Classify source headings and read underlying PRD clauses, preserving original scope and terminology.
2. Audit every dynamic route and control in all four workspaces and auth/onboarding.
3. Deduplicate shared features and create canonical feature IDs with line-level citations.
4. Produce authorization/resource ownership matrix and backend/VPS dependency mapping.
5. Review gap and decision registers, then approve Phase 01 as exhaustive against known sources.

## Files in this package

- `01-source-heading-register.csv` — source-backed topical extraction with line provenance.
- `02-screen-entry-inventory.csv` — HTML entry points.
- `03-js-label-candidates.csv` — unverified dynamic labels for follow-up.
- `04-domain-scope-registry.csv` — 27 domain categories and phase assignments.
- `05-documentation-roadmap.csv` — 24 proposed phases.
- `06-decision-register.csv` — 15 unresolved decisions.
- `07-gap-register.csv` — 12 identified gaps.

**Review status:** Initial Phase 01 baseline completed. Exhaustive reconciliation and sign-off remain outstanding.
