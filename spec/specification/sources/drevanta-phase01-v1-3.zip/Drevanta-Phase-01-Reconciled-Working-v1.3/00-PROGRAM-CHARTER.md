# Drevanta — Documentation Program Charter

**Version:** 1.1 | **Status:** Working baseline, pending full source reconciliation | **Audience:** Human engineers first; AI engineering agents second.

## Mission
Produce the Complete Platform Architecture, Engineering & VPS Integration Specification for a self-hosted Linux management platform with Server & Platform Administration, Hosting Provider/Reseller/Agency, Website Owner, and Developer workspaces. This program produces **documentation**, not production backend code or deployments.

## Sources and authority
1. Explicit approved decisions; 2. persona PRDs and platform specifications; 3. approved v2.1 UI prototype; 4. inferred engineering needs, marked proposed. Conflicts between approved sources are not silently resolved. An approved UI does not establish a real backend or production authorization.

## Required end-to-end feature contract
For each capability: stable feature ID; provenance; intended users; permissions and tenant/resource scope; UI fields/states/errors/accessibility; workflows including exceptional paths; API routes and request/response/error/idempotency contracts; persistent entities and migrations; background jobs and concurrency/retry/cancellation rules; VPS agent and privileged operations; security and audit; monitoring/backups/recovery/deletion; acceptance tests and evidence; dependencies; open decisions.

## Deliverables
Complete source-reconciled inventory, scope registry, 25-phase documentation suite (expand as needed), feature-to-API/data/permission/VPS/test traceability, architecture decision records, threat model, implementation sequence, release/test standards, and final searchable master compilation with machine-readable registries.

## Completion gates
- Inventory: every known PRD requirement and UI control has a traceable disposition, including excluded and unresolved.
- Specification: no approved feature lacks documented behaviors, permission scope, error contracts, security and operational consequences, and verifiable acceptance criteria.
- Cross-document: all IDs resolve, shared definitions agree, conflicts and undecided choices are visible, and proposed contracts are not mislabeled approved.
- Release: human review, reproducible artifact build, automated link/schema/registry validation, versioned manifest and exception report.

## AI-agent handoff
Documentation is human-readable first. Agent handoff adds precise task IDs, prerequisites, tests, objective Definition of Done, Git/CI rules, secrets handling, environment boundaries, evidence collection, and approval gates. Credentials are never embedded in documents. Production-destructive and privilege-changing operations require explicit authorization.

## Non-goals of this documentation run
No claim that any prototype operation works against a VPS; no actual server deployment; no fabricated API contracts presented as accepted; no declaration of production readiness without test evidence.
