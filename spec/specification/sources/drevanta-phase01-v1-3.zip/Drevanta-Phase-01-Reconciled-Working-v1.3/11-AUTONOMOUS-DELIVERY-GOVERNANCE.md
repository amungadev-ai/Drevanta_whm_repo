# Human-first, Agent-ready Delivery Governance — Draft

**Status:** Proposed requirements for Phase 25; no credentials requested or accessed.

## Human authority and engineering review
Human reviewers own product scope, architecture decisions, privilege boundaries, production approvals and acceptance. Agent-readable manifests are derived from the same human-readable approved specification.

## Agent execution contract
1. Read approved scope and immutable source references; identify task IDs and dependencies.
2. Confirm allowed repository, branch, environment and resource scopes before acting.
3. Create an implementation plan with acceptance tests and rollback strategy.
4. Implement in a feature branch; no direct production-main commits unless explicitly authorized.
5. Run deterministic lint, type checks, unit, contract, integration, permission and isolation tests as applicable.
6. Exercise VPS operations only on an authorized disposable or staging environment; verify allowlists, isolation and idempotency.
7. Attach test reports, artifact hashes, commit SHA, environment identity, logs scrubbed of secrets, and change summary.
8. Request human approval for protected merges, destructive migrations, production credentials, firewall/SSH changes, production deployments and irreversible actions.
9. If blocked, publish a structured exception with impact, attempted diagnostics, rollback state and decision required. Never mark blocked work complete.

## Minimum release gates
- All committed requirements mapped to implementation and acceptance evidence.
- Zero unresolved critical/high release-blocking findings, subject to a human-approved risk policy.
- CI reproducible and passing; migrations/rollback verified; backup restore exercised.
- Staging install/upgrade, cross-tenant denial, least-privilege VPS execution, secret redaction and audit validated.
- Production change authorization recorded; release notes, version and rollback runbook approved.

## Security invariants
No secrets in Git, generated docs, build logs or test fixtures. No arbitrary shell from user input. No privilege escalation through UI persona switching. No agent self-approval of high-risk actions. No assumption that SSH/VPS access means authorization for destructive changes.

## Evidence schema (proposal)
`feature_id`, `test_id`, `commit_sha`, `environment_id`, `build_id`, `command_or_scenario`, `expected`, `actual`, `result`, `artifact_uri`, `timestamp`, `reviewer`, `exception_id`.

## Stop conditions
Conflicting approved requirements, ambiguous resource ownership, exposed credentials, failed security tests, unreviewed privilege expansion, data-loss risk, and unauthorized production changes.
