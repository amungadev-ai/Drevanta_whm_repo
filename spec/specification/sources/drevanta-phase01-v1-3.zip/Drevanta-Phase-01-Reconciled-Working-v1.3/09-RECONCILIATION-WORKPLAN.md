# Phase 01 — Reconciliation Workplan

**Baseline:** v2.1 approved UI and bundled PRDs; initial source-heading, screen, and label extracts are candidates, not a completed interaction audit.

## Ordered work packages
1. Normalize source citations: file path, heading, location, requirement text, version, authority.
2. Extract all UI routes and dynamically rendered components, controls, event handlers, dialogs, and states; validate in a browser.
3. Normalize every PRD requirement into atomic, stable feature records; classify approved/proposed/unresolved.
4. Link each UI control to a capability and each capability to personas, role/resource scopes, services, data, jobs, VPS actions, security, and tests.
5. Identify duplicates, omissions, contradictions, and implied capabilities; publish gap and decision records.
6. Draft the 25-phase allocation and dependency DAG; establish canonical owners for shared concepts.
7. Validate coverage and publish a reviewed Phase 01 completion report.

## No-false-completeness rule
Counts of headings, HTML files, or JS labels are discovery metrics, not feature coverage metrics. Completeness requires a reviewed requirement/control-to-feature mapping and explicit disposition of every item.

## First-pass known blockers
- Browser-driven audit of dynamically generated controls incomplete.
- No binding production API or DB contracts.
- Persona switching in prototype is not backend authorization.
- Agent privilege boundary and OS support matrix remain undecided.
- Exact production test environments, release approvals, and SLOs remain unspecified.
