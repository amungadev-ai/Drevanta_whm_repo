# Drevanta Complete Platform Architecture, Engineering & VPS Integration Specification

**Engineering audit v2.0 · 13 November 2026**  
**Baseline** Drevanta Phase 01 reconciled working v1.3  
**Scope** Specification and validation artifacts for all 25 roadmap phases

Start with [Phase 01](phases/01.md), then read in roadmap order. [Shared engineering contracts](shared-contracts.md) define recurring invariants for the control plane and VPS. [Validation](validation-report.md) describes the checks performed and where evidence is still needed.

| Phase | Specification |
| --- | --- |
| 01 | [Master inventory and scope registry](phases/01.md) |
| 02 | [Product requirements and architectural principles](phases/02.md) |
| 03 | [System architecture and service boundaries](phases/03.md) |
| 04 | [Data architecture and persistence](phases/04.md) |
| 05 | [Security architecture and threat model](phases/05.md) |
| 06 | [Bootstrap, installation and onboarding](phases/06.md) |
| 07 | [VPS agent and privileged execution model](phases/07.md) |
| 08 | [Server lifecycle, OS compatibility and updates](phases/08.md) |
| 09 | [Networking, firewall and DNS](phases/09.md) |
| 10 | [Web server, HTTPS and certificate management](phases/10.md) |
| 11 | [Runtime, process and service management](phases/11.md) |
| 12 | [Website and application lifecycle](phases/12.md) |
| 13 | [Databases, storage and file services](phases/13.md) |
| 14 | [Backups, restore and disaster recovery](phases/14.md) |
| 15 | [Developer workflows and deployment pipelines](phases/15.md) |
| 16 | [Email and external service integrations](phases/16.md) |
| 17 | [Identity, MFA, sessions and recovery](phases/17.md) |
| 18 | [Roles, permissions and tenant isolation](phases/18.md) |
| 19 | [Four-persona workspace specifications](phases/19.md) |
| 20 | [Hosting provider, reseller and customer management](phases/20.md) |
| 21 | [Monitoring, logging, alerts and audit trails](phases/21.md) |
| 22 | [Background jobs, automation and notifications](phases/22.md) |
| 23 | [APIs, integrations and extension contracts](phases/23.md) |
| 24 | [Testing, release engineering and production readiness](phases/24.md) |
| 25 | [Autonomous AI Engineering, Verification & Release Protocol](phases/25.md) |

## Registers and evidence

- [Requirements](registers/requirements.csv), [test cases](registers/tests.csv), [capability traceability](registers/capability-traceability.csv) and [release gates](registers/release-gates.csv)
- [Dependencies](registers/phase-dependencies.csv), [reconciliation](registers/reconciliation.csv), [decisions](registers/decisions.csv) and [gaps](registers/gaps.csv)
- [PRD sections](registers/prd-sections.csv), [ID-bearing source statements](registers/prd-id-statements.csv), [source headings](registers/source-heading-crosswalk.csv), [UI controls](registers/ui-controls.csv) and [prototype pages](registers/prototype-pages.csv)
- [Phase validation](registers/phase-validation.csv) and [manifest](manifest.json)
- Unmodified inputs in `sources/`. The source ZIPs preserve the full original inventories, wording and design references.

## Reading the status

Source listed means an attached PRD or registry describes a capability. Prototype evidence covers files and static discovery. Proposed means a behavior, interface, policy or test needs owner review before engineering use. Structurally checked means the package’s documented mappings and references passed validation. A runtime pass requires attributable execution evidence. No software implementation or deployment was performed.

## Audit package

- [Readiness assessment](release-readiness.md) and [completion and release gates](completion-and-release.md)
- [Audit findings](registers/audit-findings.csv), [full traceability matrix](registers/full-traceability.csv) and [expanded test scenarios](registers/expanded-tests.csv)
- [Source API catalog](registers/source-api-catalog.csv), [source role and permission extract](registers/source-role-permission-register.csv), [source data extract](registers/source-data-register.csv) and [historical decisions](registers/source-decisions-and-invariants.csv)

Source references are relative to the sealed sources. The audit amendments govern where they change earlier draft wording. The original specification ZIP is included for provenance.
